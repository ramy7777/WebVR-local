const { Server } = require('socket.io');

exports.handler = async (event, context) => {
  const io = new Server();

  io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('join', (peerId) => {
      socket.join('vr-room');
      socket.to('vr-room').emit('peer-joined', peerId);
      io.in('vr-room').allSockets().then((sockets) => {
        io.to(socket.id).emit('peers', Array.from(sockets));
      });
    });

    socket.on('disconnect', () => {
      console.log('A user disconnected');
      socket.to('vr-room').emit('peer-left', socket.id);
    });
  });

  return {
    statusCode: 200,
    body: JSON.stringify({ message: "Signaling server is running" }),
  };
};

