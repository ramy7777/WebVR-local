import React, { useEffect, useRef } from 'react';
import Head from 'next/head';
import dynamic from 'next/dynamic';

const VRScene = dynamic(() => import('../components/VRScene'), { ssr: false });

export default function Home() {
  return (
    <div>
      <Head>
        <title>WebVR Multiplayer Auto-Join</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <script src="https://aframe.io/releases/1.4.0/aframe.min.js"></script>
      </Head>
      <VRScene />
    </div>
  );
}

