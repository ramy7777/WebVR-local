import React from 'react';
import Head from 'next/head';
import dynamic from 'next/dynamic';

const VRScene = dynamic(() => import('../components/VRScene'), { ssr: false });

export default function Home() {
  return (
    <div>
      <Head>
        <title>WebVR Multiplayer Auto-Join (Local Dev)</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <script src="https://aframe.io/releases/1.4.0/aframe.min.js"></script>
      </Head>
      <div style={{ position: 'absolute', top: 10, left: 10, zIndex: 1000, background: 'rgba(0,0,0,0.5)', color: 'white', padding: '5px' }}>
        Local Development
      </div>
      <VRScene />
    </div>
  );
}

