import { Server } from 'socket.io';

const SocketHandler = (req: any, res: any) => {
  if (res.socket.server.io) {
    console.log('Socket is already running');
  } else {
    console.log('Socket is initializing');
    const io = new Server(res.socket.server);
    res.socket.server.io = io;

    io.on('connection', (socket) => {
      console.log('A user connected');

      socket.on('join', (peerId) => {
        socket.join('vr-room');
        socket.to('vr-room').emit('peer-joined', peerId);
        io.in('vr-room').allSockets().then((sockets) => {
          io.to(socket.id).emit('peers', Array.from(sockets));
        });
      });

      socket.on('disconnect', () => {
        console.log('A user disconnected');
        socket.to('vr-room').emit('peer-left', socket.id);
      });
    });
  }
  res.end();
};

export default SocketHandler;

